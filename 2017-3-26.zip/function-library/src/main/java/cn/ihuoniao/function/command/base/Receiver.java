package cn.ihuoniao.function.command.base;

/**
 * Created by sdk-app-shy on 2017/3/20.
 */

public abstract class Receiver {


}
