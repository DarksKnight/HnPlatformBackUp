package cn.ihuoniao.platform.wxapi;

import com.umeng.socialize.weixin.view.WXCallbackActivity;

/**
 * Created by sdk-app-shy on 2017/3/23.
 */

public class WXEntryActivity extends WXCallbackActivity {

}
