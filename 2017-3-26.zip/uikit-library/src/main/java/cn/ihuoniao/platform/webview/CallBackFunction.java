package cn.ihuoniao.platform.webview;

public interface CallBackFunction {
	
	public void onCallBack(String data);

}
