package cn.ihuoniao;

/**
 * Created by sdk-app-shy on 2017/3/17.
 */

public class API {

    public static final String HTTP = "http://";

    public static final String IP = "ihuoniao.cn/";

    public static final String APP_CONFIG  = HTTP + IP + "api/appConfig.json";

}
