package cn.ihuoniao.event;

import cn.ihuoniao.event.base.StoreChangeEvent;

/**
 * Created by sdk-app-shy on 2017/3/21.
 */

public class QQEvent extends StoreChangeEvent {

}
