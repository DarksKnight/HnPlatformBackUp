package cn.ihuoniao.event.base;

/**
 * Created by sdk-app-shy on 2017/3/17.
 */

public abstract class StoreChangeEvent {

    public String eventName = "";
}
