package cn.ihuoniao.actions;

import java.util.Map;

import cn.ihuoniao.actions.base.BaseAction;

/**
 * Created by sdk-app-shy on 2017/3/21.
 */

public class QQAction extends BaseAction<Map<String, Object>> {

    public QQAction(String type, Map<String, Object> data) {
        super(type, data);
    }
}
