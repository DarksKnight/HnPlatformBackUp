package cn.ihuoniao.actions;

import java.util.Map;

import cn.ihuoniao.actions.base.BaseAction;

/**
 * Created by sdk-app-shy on 2017/3/23.
 */

public class WeiboAction extends BaseAction<Map<String, Object>> {
    public WeiboAction(String type, Map<String, Object> data) {
        super(type, data);
    }
}
