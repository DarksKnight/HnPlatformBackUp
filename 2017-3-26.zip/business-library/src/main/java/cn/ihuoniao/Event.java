package cn.ihuoniao;

/**
 * Created by sdk-app-shy on 2017/3/21.
 */

public class Event {
    public static final String GET_APP_INFO = "getAppInfo";
    public static final String APP_LOGOUT = "appLogout";

    public static final String LOGIN_QQ = "qqLogin";
    public static final String LOGIN_WECHAT = "wechatLogin";
    public static final String LOGIN_WEIBO = "weiboLogin";
    public static final String SHARE_UMENG = "umengShare";
}
