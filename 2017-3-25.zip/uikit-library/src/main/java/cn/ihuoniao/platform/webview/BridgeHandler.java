package cn.ihuoniao.platform.webview;

public interface BridgeHandler {
	
	void handler(String data, CallBackFunction function);

}
