package cn.ihuoniao;

/**
 * Created by sdk-app-shy on 2017/3/17.
 */

public class TYPE {

    public static final String TYPE_APP_CONFIG = "type_app_config";
    public static final String TYPE_LOGIN_WECHAT_INFO = "type_login_wechat_info";

    public static final String TYPE_GET_APP_INFO = "type_get_app_info";
    public static final String TYPE_QQ_INIT = "type_qq_init";
    public static final String TYPE_QQ_LOGIN = "type_qq_login";
    public static final String TYPE_QQ_SHARE = "type_qq_share";
    public static final String TYPE_QQ_ZONE_SHARE = "type_qq_zone_share";
    public static final String TYPE_WECHAT_INIT = "type_wechat_init";
    public static final String TYPE_WECHAT_LOGIN = "type_wechat_login";
    public static final String TYPE_WEIBO_INIT = "type_weibo_init";
    public static final String TYPE_WEIBO_LOGIN = "type_weibo_login";
    public static final String TYPE_UMENG_INIT = "type_umeng_init";
    public static final String TYPE_UMENG_SHARE = "type_umeng_share";

    public static final String REGISTER_GET_APP_INFO = "store_get_app_info";
    public static final String REGISTER_STORE_APP_CONFIG = "store_app_config";
    public static final String REGISTER_STORE_QQ = "store_qq";
    public static final String REGISTER_STORE_WECHAT = "store_wechat";
    public static final String REGISTER_STROE_WEIBO = "store_weibo";
    public static final String REGISTER_STORE_UMENG = "store_umeng";
}
