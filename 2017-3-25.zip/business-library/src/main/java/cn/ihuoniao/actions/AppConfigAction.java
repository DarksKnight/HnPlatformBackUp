package cn.ihuoniao.actions;

import cn.ihuoniao.actions.base.BaseAction;

/**
 * Created by sdk-app-shy on 2017/3/17.
 */

public class AppConfigAction extends BaseAction {

    public AppConfigAction(String type, Object data) {
        super(type, data);
    }
}
