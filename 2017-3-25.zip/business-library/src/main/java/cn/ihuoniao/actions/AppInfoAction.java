package cn.ihuoniao.actions;

import cn.ihuoniao.actions.base.BaseAction;

/**
 * Created by sdk-app-shy on 2017/3/22.
 */

public class AppInfoAction extends BaseAction {

    public AppInfoAction(String type, Object data) {
        super(type, data);
    }
}
