package cn.ihuoniao.actions;

import java.util.Map;

import cn.ihuoniao.actions.base.BaseAction;

/**
 * Created by sdk-app-shy on 2017/3/24.
 */

public class UMengAction extends BaseAction<Map<String, Object>> {

    public UMengAction(String type, Map<String, Object> data) {
        super(type, data);
    }
}
