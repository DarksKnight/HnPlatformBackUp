package cn.ihuoniao;

/**
 * Created by sdk-app-shy on 2017/3/17.
 */

public class Constant {

    public static final String HN_SETTING = "hn_setting";

}