package cn.ihuoniao.function.listener;

/**
 * Created by sdk-app-shy on 2017/3/22.
 */

public interface StatusListener {

    public void start();

    public void end();
}
