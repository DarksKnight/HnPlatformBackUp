package cn.ihuoniao.function.listener;

/**
 * Created by sdk-app-shy on 2017/3/23.
 */

public interface ResultListener<T> {
    void onResult(T result);
}
