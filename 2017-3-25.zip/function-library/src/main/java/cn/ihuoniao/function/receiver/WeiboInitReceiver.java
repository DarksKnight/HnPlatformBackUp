package cn.ihuoniao.function.receiver;

import cn.ihuoniao.function.command.base.Receiver;

/**
 * Created by sdk-app-shy on 2017/3/23.
 */

public class WeiboInitReceiver extends Receiver {

//    public SsoHandler init(Activity activity, String appKey) {
//        String scope =
//                "email,direct_messages_read,direct_messages_write,"
//                        + "friendships_groups_read,friendships_groups_write,statuses_to_me_read,"
//                        + "follow_app_official_microblog," + "invitation_write";
//        AuthInfo authInfo = new AuthInfo(activity, appKey, "http://ihuoniao.cn", scope);
//        return new SsoHandler(activity, authInfo);
//    }
}
